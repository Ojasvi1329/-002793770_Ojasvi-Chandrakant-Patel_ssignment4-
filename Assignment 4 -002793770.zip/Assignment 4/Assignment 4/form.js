function showUP(object, type){
  var stat=false;
  var curr=type;
 //  console.log("Test");
 stat!=stat;
 var stat=document.getElementById(curr).checked;
 stat!=stat;
 console.log(stat);
 if(stat){
     document.getElementById("comments1").style.display="block";
     document.getElementById("comments11").style.display="block";
     document.getElementById("comments11").attributes["required"]=true;
 }else{
     document.getElementById("comments1").style.display="none";
     document.getElementById("comments11").style.display="none";
     document.getElementById("comments11").attributes["required"]=false;
 }
}


function showText(){
   
   var eleout=document.getElementById("drinks").value;
   if(eleout=="tea"){
       
       document.getElementById("source2").style.display="none";
       document.getElementById("source22").style.display="none";
       document.getElementById("source3").style.display="none";
       document.getElementById("source33").style.display="none";
       document.getElementById("source4").style.display="none";
       document.getElementById("source44").style.display="none";
document.getElementById("source1").style.display="block";
       document.getElementById("source11").style.display="block";
       document.getElementById("comments11").style.display="none";
       document.getElementById("comments1").style.display="none";
       
   }
  else if(eleout=="coffee"){
    document.getElementById("source2").style.display="block";
       document.getElementById("source22").style.display="block";
       document.getElementById("source3").style.display="none";
       document.getElementById("source33").style.display="none";
       document.getElementById("source4").style.display="none";
       document.getElementById("source44").style.display="none";
       document.getElementById("source1").style.display="none";
       document.getElementById("source11").style.display="none";
       document.getElementById("comments11").style.display="none";
       document.getElementById("comments1").style.display="none";
  }
  else if(eleout=="Select an option"){
    document.getElementById("source2").style.display="none";
       document.getElementById("source22").style.display="none";
       document.getElementById("source3").style.display="none";
       document.getElementById("source33").style.display="none";
       document.getElementById("source4").style.display="none";
       document.getElementById("source44").style.display="none";
       document.getElementById("source1").style.display="none";
       document.getElementById("source11").style.display="none";
       document.getElementById("comments11").style.display="none";
       document.getElementById("comments1").style.display="none";
       document.getElementById("source123").style.display="block";
       document.getElementById("source23").style.display="block";
  }



else if(eleout=="coke"){
document.getElementById("source2").style.display="none";
       document.getElementById("source22").style.display="none";
       document.getElementById("source3").style.display="block";
       document.getElementById("source33").style.display="block";
       document.getElementById("source4").style.display="none";
       document.getElementById("source44").style.display="none";
       document.getElementById("source1").style.display="none";
       document.getElementById("source11").style.display="none";
       document.getElementById("comments11").style.display="none";
       document.getElementById("comments1").style.display="none";
  }

  else if(eleout=="soda"){
    document.getElementById("source2").style.display="none";
           document.getElementById("source22").style.display="none";
           document.getElementById("source3").style.display="none";
           document.getElementById("source33").style.display="none";
           document.getElementById("source4").style.display="block";
           document.getElementById("source44").style.display="block";
           document.getElementById("source1").style.display="none";
           document.getElementById("source11").style.display="none";

           document.getElementById("comments11").style.display="none";
           document.getElementById("comments1").style.display="none";
      }
    else{
        document.getElementById("source2").style.display="none";
        document.getElementById("source22").style.display="none";
        document.getElementById("source3").style.display="none";
        document.getElementById("source33").style.display="none";
        document.getElementById("source4").style.display="none";
        document.getElementById("source44").style.display="none";
        document.getElementById("source1").style.display="none";
        document.getElementById("source11").style.display="none";

        document.getElementById("comments11").style.display="none";
        document.getElementById("comments1").style.display="none";
    }
}



var j=1;
       function getData(){

        
           // var d= DocumentFragment.getElementById("firstName");
           var name = document.getElementById("firstName").value;
           var ln= document.getElementById("lastName").value;
           var ph =document.getElementById("phoneNumber").value;
           var ema= document.getElementById("emailId").value;
           var stAdd1= document.getElementById("streetAddress1").value;
           var stAdd2 = document.getElementById("streetAddress2").value;
           var stte=document.getElementById("state").value;
           var city=document.getElementById("city").value;
           var zp = document.getElementById("zipcode").value;
           var com= document.getElementById("comments").value;
           var dd=document.getElementById("drinks").value;
           var xyys=document.getElementById('comments1').value;
           
           
           var radios = document.querySelectorAll('input[name="title"]:checked');
            var vel = radios.length>0? radios[0].value: '';

            var checkbox = document.querySelectorAll('input[name="source"]:checked');
            var vel1 = checkbox.length>0? checkbox[0].value: '';

            var checkbox1 = document.querySelectorAll('input[name="source100"]:checked');
            var vel11 = checkbox1.length>0? checkbox1[0].value: '';

            
           
           if (name=="" || ln=="" || ph=="" || ema=="" || zp=="" || vel=="" || vel1=="" || com=="" || dd=="default"){
               alert("All fields are mandatory");
           }
            else if(vel11!='' && xyys==""){
                alert("All fields are mandatory");
            }
           else{
           
               

                   //var content="";
               
                   //content+="<tr><td>"+name+"</td><td>"+ln+"</td></tr>";
                   
                   
                   
                   var userTable=document.getElementById("userTable");
                   // userTable.tBodies[0].innerHTML=content;
                   // userTable.style.display="block";
                   
for(var i=j;i<=j;i++){
                   var row = list.insertRow(i);
var cell1 = row.insertCell(0);
var cell2 = row.insertCell(1);
var cell3 =row.insertCell(2);
var cell4 =row.insertCell(3);
var cell5 =row.insertCell(4);
var cell6 =row.insertCell(5);
var cell7 =row.insertCell(6);
var cell8 =row.insertCell(7);
var cell9=row.insertCell(8);
var cell10=row.insertCell(9);
var cell11=row.insertCell(10);
var cell12=row.insertCell(11);
cell1.innerHTML = name;
cell2.innerHTML = ln;
cell3.innerHTML = ema;
cell4.innerHTML =ph;
cell5.innerHTML=stAdd1;
cell6.innerHTML=stAdd2;
cell7.innerHTML=city;
cell8.innerHTML=stte;
cell9.innerHTML=zp;
cell10.innerHTML=com;
cell11.innerHTML=dd;
cell12.innerHTML=xyys;




}
j=j+1;
           
document.getElementById("myForm").reset();      
       }}